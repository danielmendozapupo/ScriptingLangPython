import Proj05Runner

str = 'The lazy brown fox jumped over the fence.'
subStr = 'fox'
result = Proj05Runner.run(str,subStr)
print(result)




