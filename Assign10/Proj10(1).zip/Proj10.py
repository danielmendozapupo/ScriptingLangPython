import Proj10Runner

myKeys = b'name',b'age',b'gender'
myValues = b'Joe',b'39',b'male'
databaseName = 'database'

Proj10Runner.run(myKeys,myValues,databaseName)


