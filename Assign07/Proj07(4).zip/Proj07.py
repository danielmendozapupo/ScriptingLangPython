import Proj07Runner

str = 'The lazy brown fox'
index = 6
myList = Proj07Runner.run(str,index)
print(str)
for item in myList:
    print(item)



