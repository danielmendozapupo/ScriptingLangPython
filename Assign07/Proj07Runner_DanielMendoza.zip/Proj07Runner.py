def run(Str, index):
    print("Daniel Mendoza")
    print(Str)
    print(index)
    break1 = Str[0:index]
    break2 = Str[index -1:len(Str)]
    List1 = [break1, break2]
    return List1
