import Proj09Runner

myTuple = ('Joe is a friend.','Dick is a name.','Tom Dick and Harry.','Joe and Sue.')
myWord = 'Joe'
print(*Proj09Runner.run(myTuple,myWord))



