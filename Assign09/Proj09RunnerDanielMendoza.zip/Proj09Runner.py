import re
def run(myTuple, myWord):
    print("Daniel Mendoza")
    print(myWord)
    print(myTuple)
    resulTuple = re.compile(myWord)
    Str = filter(lambda myWord: resulTuple.search(myWord), myTuple)
    return Str