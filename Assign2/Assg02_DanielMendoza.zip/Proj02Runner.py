import turtle


class Runner(object):



    
    def __init__(self, color):
       self.color = color
       
    def run(self):
        prueba = turtle.Turtle ("turtle")
        prueba.pensize(5)
                
        
        return self.color, prueba, "Daniel E. Mendoza Pupo"
       




