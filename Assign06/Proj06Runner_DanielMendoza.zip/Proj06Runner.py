def run(Str, sep):
    #return  ["Daniel Mendoza", Str, sep] + Str.split(sep)
    return "Daniel Mendoza", Str,sep, "\n".join(Str.split(sep))