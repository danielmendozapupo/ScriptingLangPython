def getLen(myList):
    return len(myList)

